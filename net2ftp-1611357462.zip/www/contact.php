<?php
  session_start();
?>

<!DOCTYPE HTML>
<html>
<style>
<?php include 'skstyle.css'; ?>
</style>
<title> BlogIt - Novinky </title>
<link rel = "icon" href =  favicon.png
type = "image/x-icon"> 
<div class="hnav">
<a class="headera" id="active" href="contact.php">Contact</a>
<a class="headera" href="info.php">Information</a>
<div class="search">
<input type="text" name="text" value=""/>
<input type="submit" name="button" value="Search" /> 
</div>
<div class="dropdown">
    <button class="dropbtn">EN
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="kontakt.php">SK</a>
    </div>
</div>
</div>

<div class="header">
<img class="logo" src="glogo.png">
</div>
<div class="body">
<div class="navbar">
    <a href = "index.php">News</a>
    <a href = "interest.php">Interesting Posts</a>

    <?php

  if (isset($_SESSION["useruid"]))
  {
      echo "<a class='login' href='log/profile.php'>Profile Page</a>";
      echo "<a class='signup' href='log/inc/logout.php'>Sign Out</a>";
  }
  else
  {
      echo "<a class='login' href='log/loginp.php'>Sign in</a>";
      echo "<a class='signup' href='log/signup.php'>Sign up</a>";
  }
    ?>
    </div>
<div class="cont">
<p> Email: blogitinfo@gmail.com </p>
</div>



</html>