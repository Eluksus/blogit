<?php
  session_start();
?>

<!DOCTYPE HTML>
<html>
<style>
<?php include 'skstyle.css'; ?>
</style>
<title> BlogIt - Novinky </title>
<link rel = "icon" href =  favicon.png
type = "image/x-icon"> 
<div class="hnav">
<a class="headera" href="kontakt.php">Kontakt</a>
<a class="headera" href="informacie.php">Informacie</a>
<div class="search">
<input type="text" name="text" value=""/>
<input type="submit" name="button" value="Search" /> 
</div>
<div class="dropdown">
    <button class="dropbtn">SK
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="index.php">EN</a>
    </div>
</div>
</div>

<div class="header">
<img class="logo" src="glogo.png">
</div>
<div class="body">
<div class="navbar">
    <a class="active" href = "novinky.php">Novinky</a>
    <a href = "zaujimavosti.php">Zaujimavosti</a>

    <?php

  if (isset($_SESSION["useruid"]))
  {
      echo "<a class='login' href='log/profil.php'>Profil</a>";
      echo "<a class='signup' href='log/inc/logout.php'>Odhlasit sa</a>";
  }
  else
  {
      echo "<a class='login' href='log/loginsk.php'>Prihlasit sa</a>";
      echo "<a class='signup' href='log/signupsk.php'>Zaregistrovat sa</a>";
  }
    ?>
    </div>
<div class="cont">
<p> Tu pojdu najnovsie prispevky </p>
</div>



</html>