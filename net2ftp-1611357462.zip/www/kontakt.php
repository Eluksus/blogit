<?php
  session_start();
?>

<!DOCTYPE HTML>
<html>
<style>
<?php include 'skstyle.css'; ?>
</style>
<title> BlogIt - Novinky </title>
<link rel = "icon" href =  favicon.png
type = "image/x-icon"> 
<div class="hnav">
<a class="headera" id="active" href="kontakt.php">Kontakt</a>
<a class="headera"  href="informacie.php">Informacie</a>
<div class="search">
<input type="text" name="text" value=""/>
<input type="submit" name="button" value="Search" /> 
</div>
<div class="dropdown">
    <button class="dropbtn">SK
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="contact.php">EN</a>
    </div>
</div>
</div>

<div class="header">
<img class="logo" src="glogo.png">
</div>
<div class="body">
<div class="navbar">
    <a  href = "novinky.php">Novinky</a>
    <a href = "zaujimavosti.php">Zaujimavosti</a>

    <?php

  if (isset($_SESSION["useruid"]))
  {
      echo "<a class='login' href='log/profil.php'>Profil</a>";
      echo "<a class='signup' href='log/inc/logout.php'>Odhlasit sa</a>";
  }
  else
  {
      echo "<a class='login' href='log/loginp.php'>Prihlasit sa</a>";
      echo "<a class='signup' href='log/signup.php'>Zaregistrovat sa</a>";
  }
    ?>
    </div>
<div class="cont">
<p> Email: blogitinfosk@gmail.com</p>
</div>



</html>