<!DOCTYPE HTML>
<html>
<style>
<?php include '../skstyle.css'; ?>
</style>
<title> BlogIt - Registration </title>
<link rel = "icon" href =  favicon.png
type = "image/x-icon"> 
<div class="hnav">
<a class="headera" href="../contact.php">Contact</a>
<a class="headera" href="../info.php">Information</a>
<div class="search">
<input type="text" name="text" value=""/>
<input type="submit" name="button" value="Search" /> 
</div>
<div class="dropdown">
    <button class="dropbtn">EN
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="signupsk.php">SK</a>
    </div>
</div>
</div>

<div class="header">
<img class="logo" src="../glogo.png">
</div>
<div class="body">
<div class="navbar">
    <a href = "../index.php">News</a>
    <a href = "../interest.php">Interesting Posts</a>
    <a class = "login" href = "loginp.php"> Sign in</a>
    </div>
<div class = "cont">
        <form class="fields" action="inc/sign_up.php" method="post">
        <input class="input" type="text" name="uid" placeholder="Username">
        <input class="input" type="text" name="mail" placeholder="E-mail">
        <input class="input" type="password" name="pwd" placeholder="Password">
        <input class="input" type="password" name="pwd-repeat" placeholder="Repeat password">
        <button class="input" type="submit" name="signup-submit">Signup</button>


<?php

    if (isset($_GET["error"]))
    {
        if ($_GET["error"] == "emptyinput")
        {
            echo "<p>Fill in all the fields.</p>";
        }
        else if ($_GET["error"] == "invalid_Uid")
        {
            echo "<p>Choose a normal username.</p>";
        }
        else if ($_GET["error"] == "invalid_email")
        {
            echo "<p>Email doesn't exist.</p>";
        }
        else if ($_GET["error"] == "pwd_doesnt_match")
        {
            echo "<p>Passwords don't match.</p>";
        }
        else if ($_GET["error"] == "username_taken")
        {
            echo "<p>Username is already taken.</p>";
        }
        else if ($_GET["error"] == "stmt_failed")
        {
            echo "<p>Something went wrong, try again.</p>";
        }
        else if ($_GET["error"] == "none")
        {
            echo "<p>You have successfully signed up.</p>";
        }


    }


      ?>



</form>
</div>
</html>