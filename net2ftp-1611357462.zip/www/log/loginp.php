<!DOCTYPE HTML>
<html>
<style>
<?php include '../skstyle.css'; ?>
</style>
<title> BlogIt - Login </title>
<link rel = "icon" href =  favicon.png
type = "image/x-icon"> 
<div class="hnav">
<a class="headera" href="../contact.php">Contact</a>
<a class="headera" href="../info.php">Information</a>
<div class="search">
<input type="text" name="text" value=""/>
<input type="submit" name="button" value="Search" /> 
</div>
<div class="dropdown">
    <button class="dropbtn">EN
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="loginsk.php">SK</a>
    </div>
</div>
</div>

<div class="header">
<img class="logo" src="../glogo.png">
</div>
<div class="body">
<div class="navbar">
    <a href = "../index.php">News</a>
    <a href = "../interest.php">Interesting posts</a>
    <a class = "signup" href = "signup.php"> Sign up</a>
    </div>
    <p></p>
    <p></p>
<div class="cont">
<form  class= "fields" action="inc/login.php" method="post">
 <input class="mail" type = "text" name="mailuid" placeholder="Username/E-mail">
 <p></p>
 <input class="pass" type = "password" name="pwd" placeholder="Password">
  <div class="buttons">
<p>  </p>
  <button class="submit" type="submit" name="login-submit">Login</button>

  </form>
  <a class="reset" href="reset-password.php">Forgot your password?</a>
  <?php

  if (isset($_GET["error"]))
  {
      if ($_GET["error"] == "emptyinput")
      {
          echo "<p>Fill in all the fields.</p>";
      }
      else if ($_GET["error"] == "wrong_login")
      {
          echo "<p>Username or password doesn't exist.</p>";
      }
  }

?>

<p></p>
    </div>
    <p></p>
    <p></p>
  </div>

<footer></footer>

</html>