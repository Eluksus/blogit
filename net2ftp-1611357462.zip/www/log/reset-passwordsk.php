<!DOCTYPE HTML>
<html>
<style>
<?php include '../skstyle.css'; ?>
</style>
<title> BlogIt - Reset </title>
<link rel = "icon" href =  favicon.png
type = "image/x-icon"> 
<div class="hnav">
<a class="headera" href="../kontakt.php">Kontakt</a>
<a class="headera" href="../informacie.php">Informacie</a>
<div class="search">
<input type="text" name="text" value=""/>
<input type="submit" name="button" value="Search" /> 
</div>
<div class="dropdown">
    <button class="dropbtn">EN
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="loginsk.php">SK</a>
    </div>
</div>
</div>

<div class="header">
<img class="logo" src="../glogo.png">
</div>
<div class="body">
<div class="navbar">
    <a href = "../novinky.php">News</a>
    <a href = "../zaujimavosti.php">Zaujimavosti</a>
    <a class = "signup" href = "signup.php"> Sign up</a>
    </div>
    <p></p>
    <p></p>
<div class="cont">
<h2>Password reset</h2>
<p>Please enter your e-mail below.</p>
<form class ="fields" action="inc/reset.php" method="post">
    <input class="mail" type="text" name="email" placeholder="E-mail">
    <button class="submit" type="submit" name="reset">Poslať</button>
<p></p>
    </div>
    <p></p>
    <p></p>
  </div>
<footer></footer>

</html>