<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use PHPMailer\PHPMailer\SMTP;

//sinclude "../inc/reset.php";
require "class.smtp.php";
require "class.phpmailer.php";

include "src/PHPMailer.php"; 
include "src/SMTP.php";
include "src/Exception.php";
try {
$mail = new PHPMailer;
$mail->isSMTP(); 
$mail->SMTPDebug = 2; 
$mail->Host = "smtp.forpsi.com"; 
$mail->Port = "587"; // typically 587 
$mail->SMTPSecure = 'tls'; // ssl is depracated
$mail->SMTPAuth = true;
$mail->Username = "postmaster@blog-it.sk";
$mail->Password = "kaQL!wGV3V";
$mail->setFrom("postmaster@blog-it.sk", "Blog-It");
$mail->addAddress($to);
$mail->isHTML(true); 
$mail->Subject = 'Password reset';
$mail->Body = "<html><p>Your password reset link: </br> <a href ".$url.">Password reset</a></p> </html>";
$mail->AltBody = '';
$mail->send();
echo 'Message has been sent';
} catch (Exception $e) {
    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
}