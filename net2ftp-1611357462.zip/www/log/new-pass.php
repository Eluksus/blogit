<!DOCTYPE HTML>
<html>
<style>
<?php include '../skstyle.css'; ?>
</style>
<title> BlogIt - Login </title>
<link rel = "icon" href =  favicon.png
type = "image/x-icon"> 
<div class="hnav">
<a class="headera" href="../contact.php">Contact</a>
<a class="headera" href="../info.php">Information</a>
<div class="search">
<input type="text" name="text" value=""/>
<input type="submit" name="button" value="Search" /> 
</div>
<div class="dropdown">
    <button class="dropbtn">EN
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="loginsk.php">SK</a>
    </div>
</div>
</div>

<div class="header">
<img class="logo" src="../glogo.png">
</div>
<div class="body">
<div class="navbar">
    <a href = "../index.php">News</a>
    <a href = "../interest.php">Interesting posts</a>
    <a class = "signup" href = "signup.php"> Sign up</a>
    </div>
    <p></p>
    <p></p>
<div class="cont">
<h2>Password reset</h2>
<p>Please enter your new password.</p>
<?php
    $selector = $_GET["selector"];
    $validator = $_GET["validator"];

    if(empty($selector) || empty($validator))
    {
        echo "Could not validate";
    }
    else 
    {
        if(ctype_xdigit($selector) !== false && ctype_xdigit($validator))
        {
            ?>  
                <form class ="fields" action="inc/new-pass-script.php" method = "post">
                <input type = "hidden" name = "selector" value="<?php echo $selector; ?>">
                <input type = "hidden" name = "validator" value="<?php echo $validator; ?>">
                <input type ="password" name = "pwd" placeholder="New Password">
                <input type ="password" name = "pwdr" placeholder="Repeat Password">
                <button type = "submit" name = "reset-pass">Reset password</button>
                </form>
            <?php
        }

    }



    ?>
<p></p>
    </div>

    <p></p>
    <p></p>
  </div>
<footer></footer>

</html>