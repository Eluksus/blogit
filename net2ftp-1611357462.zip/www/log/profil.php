<?php
  session_start();
?>

<!DOCTYPE HTML>
<html>
<style>
<?php include '../skstyle.css';
    include 'inc/databaseh.php';
    include 'inc/functions.php'; ?>
</style>
<title> BlogIt - Profil </title>
<link rel = "icon" href =  favicon.png
type = "image/x-icon"> 
<div class="hnav">
<a class="headera" href="../kontakt.php">Kontakt</a>
<a class="headera" href="../informacie.php">Informacie</a>
<div class="search">
<input type="text" name="text" value=""/>
<input type="submit" name="button" value="Search" /> 
</div>
<div class="dropdown">
    <button class="dropbtn">SK
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="profile.php">EN</a>
    </div>
</div>
</div>

<div class="header">
<img class="logo" src="../glogo.png">
</div>
<div class="body">
<div class="navbar">
    <a href = "../novinky.php">Novinky</a>
    <a href = "../zaujimavosti.php">Zaujimavosti</a>

    <?php

  if (isset($_SESSION["useruid"]))
  {
      echo "<a id='active' class='login' href='profil.php'>Profil</a>";
      echo "<a class='signup' href='inc/logout.php'>Odhlasit sa</a>";
  }
  else
  {
      echo "<a class='login' href='log/loginp.php'>Prihlasit sa</a>";
      echo "<a class='signup' href='log/signup.php'>Zaregistrovat sa</a>";
  }
    ?>
    </div>
<div class="info">
<h4>Informácie o vašom účte:</h4>
<form action ="fotka.php" method="POST" enctype="multipart/form-data">
    <input type="file" name="file">
    <button type="submit" name="submitphoto">Pridať obrázok</button>
    </form>
<?php

$id = $_SESSION['userid'];
$q = "SELECT * FROM users WHERE idUsers = '$id'";
  $result = mysqli_query($conn,$q);
  while($row = mysqli_fetch_assoc($result))
  {
    if($row['status'] == 1)
    {
      echo "<img class='pfp' src='profilepic/profile".$id.".jpg'>";
      $username = $row['uidUsers'];
      $email = $row['emailUsers'];
      echo "<p class='profile'>Meno: $username</p>";
      echo "<p class='profile'>E-mail: $email</p>"; 


    }
    else 
    {
      echo "<img class='pfp' src='profilepic/profiledefault.jpg'>";
      $username = $row['uidUsers'];
      $email = $row['emailUsers'];
      echo "<p class='profile'>Meno: $username</p>";
      echo "<p class='profile'>E-mail: $email</p>"; 
  

    }



  }

    



?>
</div>

<div class = "posts">
<h5>Vaše príspevky:</h5>


</div>


</html>