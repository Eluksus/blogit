<!DOCTYPE HTML>
<html>
<style>
<?php include '../skstyle.css'; ?>
</style>
<title> BlogIt - Prihlasenie </title>
<link rel = "icon" href =  favicon.png
type = "image/x-icon"> 
<div class="hnav">
<a class="headera" href="../kontakt.php">Kontakt</a>
<a class="headera" href="../informacie.php">Informácie</a>
<div class="search">
<input type="text" name="text" value=""/>
<input type="submit" name="button" value="Search" /> 
</div>
<div class="dropdown">
    <button class="dropbtn">SK
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="loginp.php">EN</a>
    </div>
</div>
</div>

<div class="header">
<img class="logo" src="../glogo.png">
</div>
<div class="body">
<div class="navbar">
    <a href = "../novinky.php">Novinky</a>
    <a href = "../zaujimavosti.php">Zaujimavosti</a>
    <a class = "signup" href = "signupsk.php"> Zaregistrovat sa</a>
    </div>
    <p></p>
    <p></p>
<div class="cont">
<form  class= "fields" action="inc/login.php" method="post">
 <input class="mail" type = "text" name="mailuid" placeholder="Meno/E-mail">
 <p></p>
 <input class="pass" type = "password" name="pwd" placeholder="Heslo">
  <div class="buttons">
<p></p>
  <button class="submit" type="submit" name="login-submit">Login</button>
  </form>
  <a class="reset" href="reset-passwordsk.php">Zabudli ste si heslo?</a>
  <?php

  if (isset($_GET["error"]))
  {
      if ($_GET["error"] == "emptyinput")
      {
          echo "<p>Fill in all the fields.</p>";
      }
      else if ($_GET["error"] == "wrong_login")
      {
          echo "<p>Username or password doesn't exist.</p>";
      }
  }

?>
<p></p>
    </div>
    <p></p>
    <p></p>
  </div>
<footer></footer>

</html>