<?php

if(isset($_POST["signup-submit"]))
{

  $username = $_POST['uid'];
  $email = $_POST['mail'];
  $password = $_POST['pwd'];
  $password_repeat = $_POST['pwd-repeat'];

  require 'databaseh.php';
  require 'functions.php';





  if(emptyInputSignup($username, $email, $password, $password_repeat) !== false)
  {
    header("location: ../signup.php?error=emptyinput");
    exit();

  }
  if(invalidUid($username) !== false)
  {
    header("location: ../signup.php?error=invalid_Uid");
    exit();

  }

  if(invalidEmail($email) !== false)
  {
    header("location: ../signup.php?error=invalid_email");
    exit();

  }

  if(pwdMatch($password, $password_repeat) !== false)
  {
    header("location: ../signup.php?error=pwd_doesnt_match");
    exit();

  }

  if(uidExists($conn, $username, $email) !== false)
  {
    header("location: ../signup.php?error=username_taken");
    exit();

  }

  createUser($conn, $username, $email, $password);
}
else
{
      header("location: ../signup.php");
      exit();
}
 




