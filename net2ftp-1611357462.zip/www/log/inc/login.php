<?php

if(isset($_POST["login-submit"]))
{
 $username = $_POST["mailuid"];
 $password = $_POST["pwd"];

 require 'databaseh.php';
 require 'functions.php';

 if(emptyInputLogin($username, $password) !== false)
 {
   header("location: ../loginp.php?error=emptyinput");
   exit();

 }
 loginUser($conn, $username, $password);

}
else
{
    header("location: ../loginp.php");
    exit();
}
