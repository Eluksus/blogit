<?php
if(isset($_POST['reset'])){
    
    $selector = bin2hex(random_bytes(8));
    $token = random_bytes(32);

    $url = "http://blog-it.sk/log/new-pass.php?selector=" . $selector . "&validator=" . bin2hex($token);
    $expires = date("U") + 900;
    
    require 'databaseh.php';
    //require '../PHPMailer-master/phpmail.php';

    $email = $_POST["email"];

    $sql = "DELETE FROM passReset WHERE passResetmail=?;";
    $stmt = mysqli_stmt_init($conn);
    if(!mysqli_stmt_prepare($stmt, $sql))
    {
        echo "Error";
        exit();
    }
    else
    {
        mysqli_stmt_bind_param($stmt, "s", $email);
        mysqli_stmt_execute($stmt);
    }

    $sql = "INSERT INTO passReset (passResetmail, passResetsel, passResettok, passResetexp) VALUES (?,?,?,?);";
    $stmt = mysqli_stmt_init($conn);
    if(!mysqli_stmt_prepare($stmt, $sql))
    {
        echo "Error";
        exit();
    }
    else
    {
        $hashedToken = password_hash($token, PASSWORD_DEFAULT);
        mysqli_stmt_bind_param($stmt, "ssss", $email, $selector, $hashedToken, $expires);
        mysqli_stmt_execute($stmt);
    }

    mysqli_stmt_close($stmt);
    mysqli_close();

    $to = $email;

    require "class.smtp.php";
    require "class.phpmailer.php";
    
    include "src/PHPMailer.php"; 
    include "src/SMTP.php";
    include "src/Exception.php";
    
try {

    //kód použitý na pripojenie sa na webový mail: 
    $mail = new PHPMailer;
    $mail->isSMTP(); 
    $mail->SMTPDebug = 2; 
    $mail->Host = "smtp.forpsi.com"; 
    $mail->Port = "465"; 
    $mail->SMTPSecure = 'ssl'; 
    $mail->SMTPAuth = true;
    $mail->Username = "postmaster@blog-it.sk";
    $mail->Password = "kaQL!wGV3V";
   
    $mail->setFrom("passreset@blog-it.sk", "Blog-It");  //moja e-mail adresa
    $mail->addAddress($to); //e-mail adresa používateľa
    $mail->isHTML(true);
    //správa 
    $mail->Subject = 'Password reset';
    $mail->Body = "<html><p>Your password reset link: </br> <a href ".$url.">$url</a></p> </html>";
    $mail->AltBody = '';
    $mail->send();

} catch (Exception $e) {
    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
}
   header("location: ../reset-password.php?success");


} else{
    header("location: ../../index.php");
    exit();
}