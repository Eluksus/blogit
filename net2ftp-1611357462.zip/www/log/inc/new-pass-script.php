<?php
if(isset($_POST['reset-pass'])){

    $selector = $_POST["selector"];
    $validator = $_POST["validator"];
    $password = $_POST["pwd"];
    $repeatPass = $_POST["pwdr"];

    if(empty($password) || empty($repeatPass))
    {
        header("location: ../../signup.php?emptyfields");
        exit();
    } 
    else if ($password != $repeatPass)
    {
        
            header("location: ../../signup.php?pwdnotmatching");
            exit(); 
    }

    $date = date("U");

    require 'databaseh.php';

    $sql = "SELECT * FROM passReset WHERE passResetsel=? AND passResetexp >= ?;";
    $stmt = mysqli_stmt_init($conn);
    if(!mysqli_stmt_prepare($stmt, $sql))
    {
        echo "Error";
        exit();
    }
    else
    {
        mysqli_stmt_bind_param($stmt, "ss", $email, $date);
        mysqli_stmt_execute($stmt);
    
    $result = mysqli_stmt_get_result($stmt);
    
    if(!$row = mysqli_fetch_assoc($result))
    {
       echo "<p>Re-submit your request.</p>"; 
       exit();
    }
    else 
    {
        $tokenbin = hex2bin($validator);
        $tokencheck = password_verify($tokenbin, $row["passResettok"]);

        if($tokencheck === false)
        {
            echo "<p>Re-submit your request.</p>";     
            exit();
        }
        else if ($tokencheck === true)
        {
            $tokenemail = $row['passResetmail'];

            $sql = "SELECT * FROM users WHERE emailUsers = ?;";
            $stmt = mysqli_stmt_init($conn);
            if(!mysqli_stmt_prepare($stmt, $sql))
            {
                echo "Error";
                exit();
            }
            else
            {
                mysqli_stmt_bind_param($stmt, "s", $tokenemail);
                mysqli_stmt_execute($stmt);
                $result = mysqli_stmt_get_result($stmt);
    
                if(!$row = mysqli_fetch_assoc($result))
                {
                   echo "<p>Error.</p>"; 
                   exit();
                }
                else 
                {
                    $sql = "UPDATE users SET passUsers = ? WHERE emailUsers =?;";
                    $stmt = mysqli_stmt_init($conn);
                    if(!mysqli_stmt_prepare($stmt, $sql))
                    {
                        echo "Error";
                        exit();
                    }
                    else
                    {
                        $npassHashed = password_hash($password, PASSWORD_DEFUALT);
                        mysqli_stmt_bind_param($stmt, "ss", $npassHashed, $tokenemail);
                        mysqli_stmt_execute($stmt);

                        $sql = "DELETE FROM passReset WHERE passResetmail=?;";
                        $stmt = mysqli_stmt_init($conn);
                        if(!mysqli_stmt_prepare($stmt, $sql))
                        {
                            echo "Error";
                            exit();
                        }
                        else
                        {
                            mysqli_stmt_bind_param($stmt, "s", $email);
                            mysqli_stmt_execute($stmt);
                            header("location: ../../reset-password.php?success");
                        }



                    }
                }
            }
        }
    }

}



} 
else
{
    header("location: ../../index.php");
}