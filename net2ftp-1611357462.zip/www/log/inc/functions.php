<?php
require 'databaseh.php';

function emptyInputSignup($username, $email, $password, $password_repeat) 
{
    $result;
    if (empty($username) || empty($email) || empty($password) || empty($password_repeat))
    {
    $result = true;

    }

    else
    {
    $result = false;

    }
    return $result;
}

function invalidUid($username) 
{
    $result;
    if (!preg_match("/^[a-zA-Z0-9]*$/", $username))
    {
    $result = true;

    }
    else
    {
    $result = false;

    }
    return $result;
}

function invalidEmail($email)
{
    $result;
    if (!filter_var($email, FILTER_VALIDATE_EMAIL))
    {
    $result = true;

    }
    else
    {
    $result = false;

    }
    return $result;
}

function pwdMatch($password, $password_repeat)
{
    $result;
    if ($password !== $password_repeat)
    {
    $result = true;

    }
    else
    {
    $result = false;

    }
    return $result;
}

function uidExists($conn, $username, $email)
{
   $sql = "SELECT * FROM users WHERE uidUsers = ? OR emailUsers = ?;";
   $stmt = mysqli_stmt_init($conn);
   if (!mysqli_stmt_prepare($stmt, $sql))
   {
    header("location: ../signup.php?error=stmt_failed");
    exit();
   }

   mysqli_stmt_bind_param($stmt, "ss", $username, $email);
   mysqli_stmt_execute($stmt);

   $result_data = mysqli_stmt_get_result($stmt);

   if ($row = mysqli_fetch_assoc($result_data))
   {
    return $row;
   }

   else
   {
    $result = false;
    return $result;
   }

   mysqli_stmt_close($stmt);
}

function createUser($conn, $username, $email, $password)
{

    
   $sql = "INSERT INTO users (uidUsers, emailUsers, passUsers) values (?, ?, ?);";
   $stmt = mysqli_stmt_init($conn);
   if (!mysqli_stmt_prepare($stmt, $sql))
   {
    header("location: ../signup.php?error=stmt_failed");
    exit();
   }
   else {
   $hashedPass = password_hash($password, PASSWORD_DEFAULT);
   mysqli_stmt_bind_param($stmt, "sss", $username, $email, $hashedPass);
   mysqli_stmt_execute($stmt);
   }
   mysqli_stmt_close($stmt);
   mysqli_close();
   header("location: ../signup.php?error=none");
   exit();
   


}

   function emptyInputLogin($username, $password) 
   {
       $result;
       if (empty($username) || empty($password))
       {
       $result = true;
   
       }
       else
       {
       $result = false;
   
       }
       return $result;
   }

    function loginUser($conn, $username, $password)
    {
        $uidExists = uidExists($conn, $username, $username);


        if ($uidExists === false)
        {
            header("location: ../loginp.php?error=wrong_login");
            exit();

        }

        $passHashed = $uidExists["passUsers"];
        $check_pass = password_verify($password, $passHashed);

        if ($check_pass === false)
        {
            header("location: ../loginp.php?error=wrong_login");
            exit();
        }
        else if ($check_pass === true)
        {
            session_start();
            $_SESSION["userid"] = $uidExists["idUsers"];
            $_SESSION["useruid"] = $uidExists["uidUsers"];
            header("location: ../../novinky.php");
            exit();
        }
    }
