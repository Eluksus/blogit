<?php

$servername = "a042um.forpsi.com";
$dBUsername = "f142193";
$dBPassword = "AEknmGQv";
$dBName = "f142193";

$conn = mysqli_connect($servername, $dBUsername, $dBPassword, $dBName);
if (!$conn)
{

    die("Connection failed: ".mysqli_connect_error());

}