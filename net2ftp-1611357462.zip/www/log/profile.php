<?php
  session_start();
?>

<!DOCTYPE HTML>
<html>
<style>
<?php include '../skstyle.css';
    require 'inc/databaseh.php'; ?>
</style>
<title> BlogIt - Profile </title>
<link rel = "icon" href =  favicon.png
type = "image/x-icon"> 
<div class="hnav">
<a class="headera" href="../contact.php">Contact</a>
<a class="headera" href="../info.php">Information</a>
<div class="search">
<input type="text" name="text" value=""/>
<input type="submit" name="button" value="Search" /> 
</div>
<div class="dropdown">
    <button class="dropbtn">EN
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="profil.php">SK</a>
    </div>
</div>
</div>

<div class="header">
<img class="logo" src="../glogo.png">
</div>
<div class="body">
<div class="navbar">
    <a href = "../index.php">News</a>
    <a href = "../interest.php">Interesting Posts</a>

    <?php

  if (isset($_SESSION["useruid"]))
  {
      echo "<a id='active' class='login' href='profile.php'>Profile Page</a>";
      echo "<a class='signup' href='inc/logout.php'>Sign Out</a>";
  }
  else
  {
      echo "<a class='login' href='log/loginp.php'>Sign in</a>";
      echo "<a class='signup' href='log/signup.php'>Sign up</a>";
  }
    ?>
    </div>
    <div class="info">
<h4>Information about your profile:</h4>
<?php

$id = $_SESSION['userid'];
$q = "SELECT * FROM users WHERE idUsers = '$id'";
  $result = mysqli_query($conn,$q);
  while($row = mysqli_fetch_assoc($result))
  {
    if($row['status'] == 1)
    {
      echo "<img class='pfp' src='profilepic/profile".$id.".jpg'>";
      $username = $row['uidUsers'];
      $email = $row['emailUsers'];
      echo "<p class='profile'>Meno: $username</p>";
      echo "<p class='profile'>E-mail: $email</p>"; 


    }
    else 
    {
      echo "<img class='pfp' src='profilepic/profiledefault.jpg'>";
      $username = $row['uidUsers'];
      $email = $row['emailUsers'];
      echo "<p class='profile'>Meno: $username</p>";
      echo "<p class='profile'>E-mail: $email</p>"; 
  

    }



  }

    



?>
</div>

<div class = "posts">
<h5>Your posts:</h5>


</div>



</html>